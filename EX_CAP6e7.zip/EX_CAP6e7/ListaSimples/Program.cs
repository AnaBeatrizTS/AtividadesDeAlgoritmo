﻿namespace ListaSimples
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 5 - Colocar namespace
            // 6 - Criar os elementos
            Aluno novo = null, inicio = null, lista = null, aux = null;
            int op = 0;
            // 7 - Inserir os dados dos elementos
            do
            {
                Console.WriteLine( @"Escolha sua opção
                    1 - Para Cadastrar
                    2 - Para Listar todos
                    3 - Para Consultar um nome especifico
                    0 - Para Sair" );
                op = Convert.ToInt32(Console.ReadLine());

                switch (op)
                {
                    // 8 - Dados dos alunos
                    case 1: 
                        novo = new Aluno();
                        Console.WriteLine("Digite o nome do aluno: ");
                        novo.nome = Console.ReadLine();
                        Console.WriteLine("Digite o cpf do aluno: ");
                        novo.cpf = Console.ReadLine();
                        Console.WriteLine("Digite a nota do aluno: ");
                        novo.notas = Convert.ToDouble(Console.ReadLine());
                        
                    // 9 - Encadeamento de lista
                    // 9.1 - Colocar no inicio da lista
                        if (inicio == null)
                        {
                            inicio = novo;
                            inicio.prox = null;
                        }
                        else
                        {
                            //9.2 - Colocar no 2 nó

                            if(inicio.prox == null)
                            {
                                lista = novo;
                                inicio.prox = lista;
                                lista.prox = null;
                            }

                            lista.prox = novo;
                            lista = novo;
                            lista.prox = null;

                        }

                        break;

                    case 2:

                        // 10 - Consultar a lista

                        aux = inicio;


                        //11 - Percorrer a lista

                        while (aux != null)
                        {
                            Console.WriteLine( aux.nome);
                            Console.WriteLine(aux.cpf);
                            Console.WriteLine(aux.notas);

                            aux = aux.prox;
                        }

                        break;

                    case 3:

                        break;


                    default:
                        break;
                }

            } while (op != 0);




        }
    }
}