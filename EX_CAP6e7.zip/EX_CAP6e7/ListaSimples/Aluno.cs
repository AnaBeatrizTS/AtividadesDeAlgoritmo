﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaSimples
{
    public class Aluno
    {
        // 1 - Criar classe
        // 2 - Mudar para public a internal class
        // 3 - Colocar os atributos

        public string? nome, cpf;
        public double? notas, media;

        //4 - Criar o ponteiro, mesmo nome da classe
        public Aluno prox;

    }
}
